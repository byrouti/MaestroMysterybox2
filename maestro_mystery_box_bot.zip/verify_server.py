from flask import Flask, request, jsonify
import secrets
import random

app = Flask(__name__)

# Store user tokens and access order
user_tokens = {}  # token -> user_id mapping
user_clicks = set()  # set of user_ids who have clicked
access_order = []  # list of tokens in order of access
winners = {}  # dict of user_ids -> prize info
MAX_USERS = 10

# Prize pool configuration
PRIZE_POOL = [
    {"duration": "1 month", "accounts": 1},    # 1st winner: 1 account for 1 month
    {"duration": "1 week", "accounts": 2},     # 2nd winner: 2 accounts for 1 week
    {"duration": "1 week", "accounts": 3},     # 3rd winner: 3 accounts for 1 week
    {"duration": "1 week", "accounts": 4},     # 4th winner: 4 accounts for 1 week
    {"duration": "1 week", "accounts": 5},     # 5th winner: 5 accounts for 1 week
    {"duration": "1 week", "accounts": 6},     # 6th winner: 6 accounts for 1 week
    {"duration": "3 days", "accounts": 7},     # 7th winner: 7 accounts for 3 days
    {"duration": "3 days", "accounts": 8},     # 8th winner: 8 accounts for 3 days
    {"duration": "1 day", "accounts": 1},      # 9th winner: 1 account for 1 day
    {"duration": "1 day", "accounts": 2}       # 10th winner: 2 accounts for 1 day
]

def generate_unique_token():
    return secrets.token_urlsafe(16)

def get_random_prize():
    """Get a random prize from the available prizes"""
    available_prizes = []
    for prize in PRIZE_POOL:
        # Count how many times this exact prize combination has been awarded
        awarded = sum(1 for p in winners.values() 
                     if p["duration"] == prize["duration"] and 
                        p["accounts"] == prize["accounts"])
        if awarded < 1:  # Each prize combination can only be awarded once
            available_prizes.append(prize)
    
    return random.choice(available_prizes) if available_prizes else None

@app.route('/verify/<token>', methods=['GET'])
def verify_token(token):
    """Verify a token and record the access"""
    if token not in user_tokens:
        return jsonify({"error": "Invalid token"}), 400

    user_id = user_tokens[token]
    
    # Check if user has already clicked
    if user_id in user_clicks:
        return jsonify({"error": "You have already clicked the link"}), 400
    
    # Record the click
    user_clicks.add(user_id)
    access_order.append(token)
    
    # If we haven't reached max users and user hasn't won yet
    if len(winners) < MAX_USERS and user_id not in winners:
        prize = get_random_prize()
        if prize:
            winners[user_id] = prize
            return jsonify({
                "message": "Congratulations! You won!",
                "prize": prize
            })
    
    return jsonify({"message": "Thank you for participating!"})

@app.route('/winners', methods=['GET'])
def get_winners():
    """Get the list of winners and their prizes"""
    return jsonify({'winners': winners})

@app.route('/generate_token', methods=['POST'])
def generate_token():
    try:
        data = request.get_json()
        user_id = data.get('user_id')
        
        if not user_id:
            return jsonify({'error': 'user_id is required'}), 400
            
        token = generate_unique_token()
        user_tokens[token] = user_id
        return jsonify({'token': token})
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/reset', methods=['POST'])
def reset_tokens():
    user_tokens.clear()
    user_clicks.clear()
    access_order.clear()
    winners.clear()
    return jsonify({'status': 'reset successful'})

if __name__ == '__main__':
    app.run(port=5000)
