import logging
from datetime import datetime, time
import pytz
import random
import requests
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters, JobQueue
import sys
import atexit
import signal

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# Replace with your bot token
BOT_TOKEN = "7963123621:AAE3iruUPGZh2shH50nk3cCvokKwvP8u7dA"

# Constants
VERIFY_SERVER = "http://localhost:5000"
MAX_DAILY_USERS = 10
LEBANON_TIMEZONE = pytz.timezone('Asia/Beirut')

# Store subscribed users
subscribed_users = set()
last_winners_check = set()  # Store winners we've already congratulated

def is_time_between(start_time, end_time):
    """Check if current time is between start_time and end_time"""
    current_time = datetime.now(LEBANON_TIMEZONE).time()
    return start_time <= current_time <= end_time

def get_verification_link(user_id):
    """Generate a new verification token and return the verification link"""
    try:
        response = requests.post(
            f"{VERIFY_SERVER}/generate_token",
            json={'user_id': user_id},
            headers={'Content-Type': 'application/json'}
        )
        token = response.json()['token']
        return f"{VERIFY_SERVER}/verify/{token}"
    except Exception as e:
        logging.error(f"Failed to generate token: {str(e)}")
        return None

async def check_and_congratulate_winners(context: ContextTypes.DEFAULT_TYPE):
    """Check for new winners and send congratulation messages"""
    try:
        response = requests.get(f"{VERIFY_SERVER}/winners")
        current_winners = response.json()['winners']
        
        # Find new winners (winners we haven't congratulated yet)
        new_winners = {int(uid): prize for uid, prize in current_winners.items() 
                      if int(uid) not in last_winners_check}
        
        # Send congratulation messages to new winners
        for winner_id, prize in new_winners.items():
            try:
                congratulation_message = (
                    "🎉 Congratulations! You just won!\n\n"
                    f"🎁 Your Prize: {prize['accounts']} Maestro Premium Account{'s' if prize['accounts'] > 1 else ''} "
                    f"for {prize['duration']}\n\n"
                    "📱 Please reach out to @CrypticKimo to claim your prize!"
                )
                await context.bot.send_message(
                    chat_id=winner_id,
                    text=congratulation_message
                )
            except Exception as e:
                logging.error(f"Failed to send congratulation to {winner_id}: {str(e)}")
        
        # Update our record of congratulated winners
        last_winners_check.update(new_winners.keys())
        
    except Exception as e:
        logging.error(f"Failed to check winners: {str(e)}")

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /start is issued."""
    chat_type = update.effective_chat.type
    
    if chat_type == "private":
        await update.message.reply_text(
            "Welcome! 👋\n\n"
            "I'm a Mystery Box bot that sends daily prize links.\n"
            "Use /subscribe to start receiving links!\n\n"
            "You can also add me to your group using this link:\n"
            f"https://t.me/{context.bot.username}?startgroup=true"
        )
    else:
        await update.message.reply_text(
            "Hello! 👋 I'm ready to send mystery box links to this group!\n"
            "An admin needs to use /subscribe to start receiving daily links."
        )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /help is issued."""
    chat_type = update.effective_chat.type
    
    if chat_type == "private":
        help_text = """
Available commands:
/start - Start the bot
/help - Show this help message
/subscribe - Subscribe to receive the mystery box link
/unsubscribe - Unsubscribe from receiving the link

⏰ The link will be sent once daily at a random time between 2 PM and 6 PM Lebanon time.
🎁 The first 10 people who click will win exclusive prizes!
⚠️ You can only click the link once per day.
"""
    else:
        help_text = """
Group commands:
/subscribe - Subscribe this group to receive daily links (admin only)
/unsubscribe - Unsubscribe from daily links (admin only)
/help - Show this help message

⏰ The link will be sent once daily at a random time between 2 PM and 6 PM Lebanon time.
🎁 The first 10 people who click will win exclusive prizes!
"""
    
    await update.message.reply_text(help_text)

async def subscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Subscribe to receive daily links"""
    chat_id = update.effective_chat.id
    chat_type = update.effective_chat.type
    
    # Check if it's a group and user is admin
    if chat_type in ["group", "supergroup"]:
        user = update.effective_user
        try:
            member = await context.bot.get_chat_member(chat_id, user.id)
            if member.status not in ["administrator", "creator"]:
                await update.message.reply_text(
                    "❌ Only group administrators can subscribe to daily links."
                )
                return
        except Exception as e:
            logging.error(f"Failed to check admin status: {str(e)}")
            return
    
    if chat_id in subscribed_users:
        await update.message.reply_text(
            "This chat is already subscribed!"
        )
    else:
        subscribed_users.add(chat_id)
        if chat_type == "private":
            await update.message.reply_text(
                "You have successfully subscribed! 🎉\n\n"
                "You will receive the mystery box link between 2 PM and 6 PM. "
                "Be quick - only the first 10 people who click will win exclusive prizes!\n\n"
                "Good luck! 🍀"
            )
        else:
            await update.message.reply_text(
                "This group has been subscribed! 🎉\n\n"
                "The mystery box link will be sent here between 2 PM and 6 PM. "
                "First 10 people to click will win exclusive prizes!\n\n"
                "Good luck everyone! 🍀"
            )

async def unsubscribe_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unsubscribe from daily links"""
    chat_id = update.effective_chat.id
    chat_type = update.effective_chat.type
    
    # Check if it's a group and user is admin
    if chat_type in ["group", "supergroup"]:
        user = update.effective_user
        try:
            member = await context.bot.get_chat_member(chat_id, user.id)
            if member.status not in ["administrator", "creator"]:
                await update.message.reply_text(
                    "❌ Only group administrators can unsubscribe from daily links."
                )
                return
        except Exception as e:
            logging.error(f"Failed to check admin status: {str(e)}")
            return
    
    if chat_id in subscribed_users:
        subscribed_users.remove(chat_id)
        await update.message.reply_text(
            "Successfully unsubscribed from daily links."
        )
    else:
        await update.message.reply_text(
            "This chat is not subscribed to daily links."
        )

async def send_daily_links(context: ContextTypes.DEFAULT_TYPE):
    """Send verification links to all subscribed users"""
    # Reset the verification server and our winners check
    try:
        requests.post(f"{VERIFY_SERVER}/reset")
        last_winners_check.clear()
    except Exception as e:
        logging.error(f"Failed to reset verification server: {str(e)}")
        return

    # Send the link to all subscribed users
    for chat_id in subscribed_users:
        try:
            verification_link = get_verification_link(chat_id)
            if verification_link:
                message = (
                    "🎁 Click on [Maestro Mystery Box]({}) to win!\n\n"
                    "⚠️ Important:\n"
                    "• First 10 people to click will win exclusive prizes\n"
                    "• You can only click once per day\n"
                    "• Winners will be contacted with prize details\n\n"
                    "Good luck! 🍀"
                ).format(verification_link)
                
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=message,
                    parse_mode='Markdown',
                    disable_web_page_preview=True
                )
        except Exception as e:
            logging.error(f"Failed to send link to {chat_id}: {str(e)}")

async def reset_daily_links(context: ContextTypes.DEFAULT_TYPE):
    """Reset the verification server at midnight"""
    try:
        requests.post(f"{VERIFY_SERVER}/reset")
        last_winners_check.clear()
        logging.info("Verification server reset successful")
    except Exception as e:
        logging.error(f"Failed to reset verification server: {str(e)}")

def cleanup():
    """Cleanup function to be called on exit"""
    logging.info("Cleaning up...")
    try:
        requests.post(f"{VERIFY_SERVER}/reset")
    except:
        pass

def signal_handler(signum, frame):
    """Handle termination signals"""
    logging.info(f"Received signal {signum}")
    sys.exit(0)

def main():
    """Start the bot."""
    # Register cleanup functions
    atexit.register(cleanup)
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Create the Application
    application = Application.builder().token(BOT_TOKEN).build()

    # Add command handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("subscribe", subscribe_command))
    application.add_handler(CommandHandler("unsubscribe", unsubscribe_command))

    # Set up daily jobs
    lebanon_timezone = pytz.timezone('Asia/Beirut')
    
    # Random time between 2 PM and 6 PM
    random_hour = random.randint(14, 17)
    random_minute = random.randint(0, 59)
    
    # Create time objects and localize them
    send_time = lebanon_timezone.localize(
        datetime.now().replace(
            hour=random_hour,
            minute=random_minute,
            second=0,
            microsecond=0
        )
    ).timetz()
    
    midnight = lebanon_timezone.localize(
        datetime.now().replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0
        )
    ).timetz()
    
    # Add jobs
    if application.job_queue:
        # Schedule daily link sending
        application.job_queue.run_daily(
            send_daily_links,
            time=send_time
        )
        
        # Schedule daily reset at midnight
        application.job_queue.run_daily(
            reset_daily_links,
            time=midnight
        )
        
        # Check for winners every minute
        application.job_queue.run_repeating(
            check_and_congratulate_winners,
            interval=60,
            first=1
        )

    try:
        # Start the bot
        logging.info("Starting bot...")
        application.run_polling(drop_pending_updates=True)
    except Exception as e:
        logging.error(f"Error running bot: {str(e)}")
        sys.exit(1)

if __name__ == '__main__':
    main()
